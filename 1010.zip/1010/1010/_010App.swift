//
//  _010App.swift
//  1010
//
//  Created by Spencer Conley on 4/29/21.
//

import SwiftUI

@main
struct _010App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
