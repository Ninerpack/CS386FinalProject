//
//  _010_App.swift
//  1010!
//
//  Created by Student on 4/28/21.
//

import SwiftUI

@main
struct _010_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
