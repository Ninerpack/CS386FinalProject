//
//  Magic15Model.swift
//  Magic15
//
//  Created by Arnie on 2/17/21.
//

import Foundation

struct Magic15Model {
    var gameBoard: [ [BoardCell] ] = []
    var numberOfRows = 0
    var numberOfColumns = 0
    
    // creating the game board
    mutating func createGameFor(rows: Int, columns: Int){
        numberOfRows = rows
        numberOfColumns = columns
        
        for rowIdx in 0..<rows {
            gameBoard.append( [BoardCell]() )
            for columnIdx in 0..<columns {
                gameBoard[rowIdx].append(BoardCell(cellType: CellType.numberCell(representing: columnIdx + rowIdx * columns + 1)))
            }
        }
        
        configureCells(rows: rows, columns: columns)
    }
    
    // configures the game board cells
    mutating func configureCells (rows: Int, columns: Int){
        for row in 0..<rows{
            for column in 0..<columns{
                if case .numberCell(let n) = gameBoard[row][column].cellType {
                    if n == 16 {
                        gameBoard[row][column].cellType = CellType.blankCell
                    }
                }
            }
        }
    }
    
    // checks if the cell is tapped
    mutating func didChooseCell(row: Int, column: Int){
        if gameBoard[row][column].isExposed {
            return
        }
    }
    
    // gets the game size
    func gameSize() -> (rows: Int, columns: Int) {
        return (numberOfRows, numberOfColumns)
    }
    
    // checking to see if the current row and column are in the game board
    func isInBounds(row: Int, column: Int) -> Bool {
        if row >= 0 && row < numberOfRows && column >= 0 && column < numberOfColumns {
            return true
        }
        else {
            return false
        }
    }
    
    // switching the tile with the blank tile
    mutating func switchTiles(row: Int, column: Int) {
        if isInBounds(row: row+1, column: column) != false && gameBoard[row+1][column].cellType == CellType.blankCell // right
            {
            let temp = gameBoard[row][column]
            gameBoard[row][column] = gameBoard[row+1][column]
            gameBoard[row+1][column] = temp
            }
        else if isInBounds(row: row, column: column+1) != false && gameBoard[row][column+1].cellType == CellType.blankCell // down
            {
            let temp = gameBoard[row][column]
            gameBoard[row][column] = gameBoard[row][column+1]
            gameBoard[row][column+1] = temp
            }
            else if isInBounds(row: row-1, column: column) != false && gameBoard[row-1][column].cellType == CellType.blankCell // left
            {
                let temp = gameBoard[row][column]
                gameBoard[row][column] = gameBoard[row-1][column]
                gameBoard[row-1][column] = temp
            }
            else if isInBounds(row: row, column: column-1) != false && gameBoard[row][column-1].cellType == CellType.blankCell // up
            {
                let temp = gameBoard[row][column]
                gameBoard[row][column] = gameBoard[row][column-1]
                gameBoard[row][column-1] = temp
            }
        }
    
    // shuffles cells for the shuffle button in content view
    mutating func shuffleCells(row: Int, column: Int) {
        var i = 0
        while i < 50{
            switchTiles(row: Int.random(in: 0...3), column: Int.random(in: 0...3))
            i+=1
        }
    }
    
    // checks for ending the game. Couldn't impliment because what i was
    // trying to implement, i don't know enough about
    mutating func endGame(row: Int, column: Int) {
        // end game
    }
    
    
}

// different cell cases
enum CellType: Comparable {
    case mineCell
    case blankCell
    case numberCell(representing: Int)
}

// different cell cases
struct BoardCell {
    var cellType: CellType
    var isExposed = false
}
