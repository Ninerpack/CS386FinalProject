//
//  ContentView.swift
//  Magic15
//
//  Created by Arnie on 2/17/21.
//

import SwiftUI


struct ContentView: View {
    
    @ObservedObject var viewModel = Magic15ViewModel()
    
    
    var body: some View {
        GeometryReader { geometry in
            body(geometry)
        }
    }
    
    func body(_ geometry: GeometryProxy) -> some View {
        print("Screen Size: ", geometry.size)
        
        let colors: [Color] = [.blue, .yellow, .purple, .red, .green, .black, .gray]
        
        let ppAreaWidth = geometry.size.width * 0.05
        let ppAreaHeight = geometry.size.height * 0.05
        
        return
            VStack(alignment: .center) {
                // Title for game
                    HStack {
                        Text("1010!")
                            .foregroundColor(.red)
                            .font(.title)
                        Image(systemName: "gamecontroller.fill")
                            .font(.title)
                            .foregroundColor(.red)
                    }
                    HStack {
                        Text("Score:")
                            .foregroundColor(.red)
                            .font(.title)
                    }
                    
                    // Button view
                   /* HStack {
                        // Reset button
                        Button(action: {
                            viewModel.reset()
                        }) {
                            HStack(alignment: .center) {
                                Image(systemName: "play")
                                    .font(.subheadline)
                                Text("New Game")
                                    .foregroundColor(Color.white)
                                    .font(Font.headline.bold())
                                }
                            .padding()
                            .background(LinearGradient(gradient: Gradient(colors: [Color.red, Color.yellow]), startPoint: .leading, endPoint: .trailing))
                            .foregroundColor(.white)
                            .cornerRadius(40)
                            .animation(.easeInOut(duration: 0.5))
                        }
                        
                        .padding()
                        
                        // Shuffle button
                }*/
                    
                    // shows the game with the cells
                    buildGameView(rows: viewModel.gameSize().rows, columns: viewModel.gameSize().columns)
                
                // show puzzle pieces
                HStack {
                    buildPuzzleView().frame(width: ppAreaWidth, height: ppAreaHeight, alignment: .center)
                }
            }
    }

        
    func buildPuzzleView() -> some View{
            PuzzlePieces()
        }
    
    // builds the view for the game
    func buildGameView(rows: Int, columns: Int) -> some View {
        return VStack(spacing: spacing){
            ForEach(0..<rows, content: { row in
                return buildGameRow(row: row, columns: columns)
            })
        }
    }
    
    // builds the view for each row
    func buildGameRow(row: Int, columns: Int) -> some View {
        return HStack(spacing: spacing) {
            ForEach(0..<columns) { column in
                cellView(cell: viewModel.cellAt(row: row, column: column))
                    .onTapGesture {
                        viewModel.didTapCell(row: row, column: column)
                    }
            }
        }
    }
    let spacing: CGFloat = 2.0
}


// view for each cell
struct cellView: View {
    let cell: BoardCell
    
    // colors for the cells
    var body: some View{
        return ZStack{
            RoundedRectangle(cornerRadius: cornerRadiusForCell).aspectRatio(1.0, contentMode: .fit).foregroundColor((cell.cellType == CellType.blankCell) ? Color.gray: Color.gray)
            RoundedRectangle(cornerRadius: cornerRadiusForCell).stroke(lineWidth: strokeLineWidth).aspectRatio(1.0, contentMode: .fit)
            }
        .font(Font.headline)
        .padding(0.5)
        .animation(.easeInOut(duration: 0.2))
        }
    
    // number text for each cell
    
    let cornerRadiusForCell: CGFloat = 10.0
    let strokeLineWidth: CGFloat = 1.0

}

struct PuzzlePieces: View {

    var body: some View {
        return HStack {
            RoundedRectangle(cornerRadius: 10.0).aspectRatio(1.0, contentMode: .fill).foregroundColor(.blue)
                .onTapGesture {
                    print()
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Pieces {
    var one_square = false
    
    var two_square_h = false
    var two_square_v = false
    
    var three_square_h = false
    var three_square_v = false
    
    var four_sqaure_h = false
    var four_square_v = false
    
    var five_square_h = false
    var five_square_v = false
    
    var two_by_two_square = false
    
    var three_by_three_square = false
    
    var small_L = false
    
    var big_L = false
    
}
