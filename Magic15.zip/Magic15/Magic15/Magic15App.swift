//
//  Magic15App.swift
//  Magic15
//
//  Created by Student on 2/17/21.
//

import SwiftUI

@main
struct Magic15App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
