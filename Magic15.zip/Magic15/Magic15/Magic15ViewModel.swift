//
//  Magic15ViewModel.swift
//  Magic15
//
//  Created by Arnie on 2/17/21.
//

import Foundation

class Magic15ViewModel: ObservableObject {
    @Published var gameModel = Magic15Model()
    
    var _gameInProgress = false
    var gameRows = 10
    var gameCols = 10
    
    // checks if a cell is tapped
    func didTapCell(row: Int, column: Int) {
        print("Tapped Cell at \(row), \(column)")
        gameModel.didChooseCell(row: row, column: column)
        gameModel.switchTiles(row: row, column: column)
    }
    
    // checks if game is in progress
    func gameInProgress() -> Bool {
        return _gameInProgress
    }
    
    // init to show the actual view
    init() {
        gameModel.createGameFor(rows: gameRows, columns: gameCols)
    }
    
    // resets the cells
    func reset() {
        gameModel = Magic15Model()
        gameModel.createGameFor(rows: gameRows, columns: gameCols)
        _gameInProgress = false
    }
    
    // moves the cells when tapped
    func moveCells() {
        gameModel.shuffleCells(row: gameRows, column: gameCols)
    }
    
    // gets the cell when tapped
    func cellAt(row: Int, column: Int) -> BoardCell {
        return gameModel.gameBoard[row][column]
    }
    
    // gets the game size
    func gameSize() -> (rows: Int, columns: Int) {
        return gameModel.gameSize()
    }
    
    // when the game is finished
    func gameFinished() {
        if !_gameInProgress {
            print("Done")
        }
        gameModel.shuffleCells(row: gameRows, column: gameCols)
    }
    

}
